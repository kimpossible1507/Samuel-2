@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class
)
package com.samuel.plantassamuel

import android.media.MediaPlayer
import android.os.Bundle
import android.graphics.BitmapFactory
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.LinearEasing
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Fullscreen: hide system bars
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        setContent { AppRoot() }
    }
}

@Composable
fun AppRoot() {
    val context = LocalContext.current

    // Dynamic font: res/font/app_font.ttf if present, else default
    val fontResId = remember {
        context.resources.getIdentifier("app_font", "font", context.packageName)
    }
    val appFontFamily = if (fontResId != 0) FontFamily(Font(fontResId)) else FontFamily.Default

    MaterialTheme(
        typography = MaterialTheme.typography.copy(
            bodyLarge = MaterialTheme.typography.bodyLarge.copy(fontFamily = appFontFamily),
            bodyMedium = MaterialTheme.typography.bodyMedium.copy(fontFamily = appFontFamily),
            bodySmall = MaterialTheme.typography.bodySmall.copy(fontFamily = appFontFamily),
            titleLarge = MaterialTheme.typography.titleLarge.copy(fontFamily = appFontFamily),
            titleMedium = MaterialTheme.typography.titleMedium.copy(fontFamily = appFontFamily),
            titleSmall = MaterialTheme.typography.titleSmall.copy(fontFamily = appFontFamily),
            headlineLarge = MaterialTheme.typography.headlineLarge.copy(fontFamily = appFontFamily)
        )
    ) {
        AppScaffold()
    }
}

// ---------- DATA ----------
data class Category(
    val key: String,
    val title: String,
    val summary: String,
    val detail: String
)

data class Plant(
    val key: String,
    val name: String,
    val categories: List<Category>
)

val carnivorousCategories: List<Category> = listOf(
    Category("morfologia","Morfología y trampas","Tipos de trampas (cepos, jarros, pegajosas) y adaptaciones.","Descripción detallada de morfologías: trampas activas (Dionaea) con células motoras y cambios de turgencia; pasivas (Nepenthes/Sarracenia) con jarros y superficies cerosas. Microestructura de tricomas, glándulas digestivas, zonas de deslizamiento. Relación área/volumen de trampas y costo energético."),
    Category("fotosintesis","Fotosíntesis y balance energético","Cómo equilibran captura de presas con la fotosíntesis.","Estrategias C3 predominantes; limitaciones en suelos pobres; inversión en estructuras de captura vs. área foliar; trade-offs ecológicos. Influencia de luz y humedad en tasa fotosintética y eficiencia del uso del agua."),
    Category("quimica_digestiva","Química digestiva","pH, enzimas y catabolitos del fluido digestivo.","Secreción de proteasas (como nepentesinas), quitinasas y fosfatasas ácidas. Rangos de pH típicos 2–5 según género. Complejos fenólicos y acción antimicrobiana. Regulación inducida por presa y reciclaje de nutrientes."),
    Category("microbiota","Microbiota asociada","Microbioma en jarros y superficies digestivas.","Comunidades bacterianas y fúngicas que colaboran en la descomposición; sucesión ecológica dentro de los jarros; mutualismos y control de patógenos; efectos en disponibilidad de N y P."),
    Category("absorcion","Absorción y transporte","Cómo pasan N/P desde la trampa al resto de la planta.","Transporte apoplástico y simplástico; papel de transportadores de amonio/nitrato; complejos de fosfato; rutas xilemáticas y floemáticas; re-alocación estacional."),
    Category("germinacion","Germinación y crecimiento","Requerimientos de sustrato, humedad y luz.","Semillas con latencia leve; estratificación en algunas especies; sustratos ácidos con turba y arena silícea; velocidad de crecimiento lenta; sensibilidad a sales y a compactación del sustrato."),
    Category("ecologia","Ecología y hábitat","Suelos oligotróficos, turberas y bordes de bosques.","Ambientes con escasez de nitrógeno y fósforo; incendios periódicos en algunos hábitats; competencia reducida; importancia de nivel freático y microclima."),
    Category("cuidados","Cuidados domésticos","Agua pura, mucha luz, sustrato aireado y sin fertilizantes.","Riego con agua destilada/lluvia; alta luminosidad indirecta; evitar fertilizar el sustrato; alimentación ocasional con insectos reales; macetas plásticas claras para controlar humedad."),
    Category("reproduccion","Reproducción y propagación","Esquejes, división de rizomas y cultivo in vitro.","Propagación vegetativa por estolones/rizomas; micropropagación para conservación; polinización cruzada manual; tiempos de floración y viabilidad de semillas."),
    Category("conservacion","Conservación y ética","Colecta responsable y protección de hábitats.","Amenazas por pérdida de hábitat y colecta ilegal; importancia de viveros certificados; directrices para cultivo ético; impacto del comercio y regulación.")
)

val samplePlant = Plant("carnivoras","Plantas carnívoras", carnivorousCategories)

// ---------- ASSET HELPERS ----------
@Composable
fun assetImageOrNull(path: String): ImageBitmap? {
    val context = LocalContext.current
    return remember(path) {
        runCatching {
            context.assets.open(path).use { input ->
                BitmapFactory.decodeStream(input)?.asImageBitmap()
            }
        }.getOrNull()
    }
}

@Composable
fun AnimatedBrazilBackground(modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "bg")
    val t by infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(8000, easing = LinearEasing)),
        label = "t"
    )
    val colors = listOf(Color(0xFF0D7C3B), Color(0xFFF7C600), Color(0xFF0E58B0))
    Box(modifier = modifier.background(Brush.linearGradient(
        colors = listOf(
            colors[0].copy(alpha = 0.8f),
            colors[1].copy(alpha = 0.5f + 0.3f * kotlin.math.abs(0.5f - t)),
            colors[2].copy(alpha = 0.8f)
        )
    )))
}

// ---------- AUDIO ----------
@Composable
fun BackgroundAudioPlayer() {
    val context = LocalContext.current
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var trackIndex by remember { mutableStateOf(0) }
    val tracks = remember {
        runCatching { context.assets.list("audio")?.filter { it.lowercase().endsWith(".mp3") } ?: emptyList() }
            .getOrDefault(emptyList())
    }
    DisposableEffect(tracks) {
        if (tracks.isNotEmpty()) {
            fun prepareAndStart(i: Int) {
                player?.release()
                val p = MediaPlayer()
                val afd = context.assets.openFd("audio/" + tracks[i])
                p.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                p.setVolume(0.15f, 0.15f)
                p.isLooping = false
                p.setOnCompletionListener {
                    val next = (trackIndex + 1) % tracks.size
                    trackIndex = next
                    prepareAndStart(next)
                }
                p.prepare()
                p.start()
                player = p
            }
            prepareAndStart(trackIndex)
        }
        onDispose { player?.release(); player = null }
    }
}

// ---------- UI ----------
@Composable
fun AppScaffold() {
    var showMenu by remember { mutableStateOf(false) }
    var showSheet by remember { mutableStateOf<Category?>(null) }

    val homeBg = assetImageOrNull("backgrounds/home/home.jpg")
        ?: assetImageOrNull("backgrounds/home/home.png")

    Box(modifier = Modifier.fillMaxSize()) {
        if (homeBg != null) {
            Image(bitmap = homeBg, contentDescription = null,
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            AnimatedBrazilBackground(modifier = Modifier.fillMaxSize())
        }

        Column(modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)) {

            Spacer(Modifier.height(8.dp))

            Box(modifier = Modifier.fillMaxWidth().weight(1f),
                contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Aplicación de Samuel", fontSize = 36.sp, fontWeight = FontWeight.Bold, color = Color.Black, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Text("prueba 2", fontSize = 16.sp, color = Color.Black.copy(alpha = 0.8f), textAlign = TextAlign.Center)
                }
            }

            Text(samplePlant.name, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Color.Black)

            LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxWidth().heightIn(min = 300.dp)) {
                items(samplePlant.categories) { cat -> CategoryCard(cat) { showSheet = cat } }
            }

            Spacer(Modifier.height(12.dp))
        }

        val scale by animateFloatAsState(targetValue = if (showMenu) 1.1f else 1f, animationSpec = tween(300, easing = FastOutSlowInEasing), label = "menuScale")
        Box(modifier = Modifier.padding(16.dp).size(56.dp).clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.7f))
            .clickable { showMenu = !showMenu }
            .shadow(8.dp, CircleShape)
            .align(Alignment.TopStart)) {
            Icon(Icons.Default.Menu, contentDescription = "Menú", tint = Color.White,
                modifier = Modifier.align(Alignment.Center).fillMaxSize(0.6f * scale))
        }

        AnimatedVisibility(visible = showMenu) {
            val menuBg = assetImageOrNull("backgrounds/menu/menu.jpg")
                ?: assetImageOrNull("backgrounds/menu/menu.png")
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)).clickable { showMenu = false }) {
                Surface(modifier = Modifier.fillMaxHeight().width(280.dp),
                    shape = RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp),
                    tonalElevation = 8.dp) {
                    Box(Modifier.fillMaxSize()) {
                        if (menuBg != null) {
                            Image(bitmap = menuBg, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        } else {
                            AnimatedBrazilBackground(Modifier.fillMaxSize())
                        }
                        Column(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.6f)).padding(16.dp)) {
                            Text("Catálogo", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                            Spacer(Modifier.height(8.dp))
                            Text("Plantas carnívoras", fontSize = 16.sp, color = Color.Black)
                        }
                    }
                }
            }
        }

        val sheetCat = showSheet
        if (sheetCat != null) {
            val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = True)
            ModalBottomSheet(onDismissRequest = { showSheet = null }, sheetState = sheetState, dragHandle = null) {
                CategoryDetail(sheetCat)
            }
        }

        BackgroundAudioPlayer()
    }
}

@Composable
fun CategoryCard(category: Category, onClick: () -> Unit) {
    val key = category.key
    val img = assetImageOrNull("backgrounds/categories/$key.jpg")
        ?: assetImageOrNull("backgrounds/categories/$key.png")

    Box(modifier = Modifier.padding(8.dp).aspectRatio(1.2f)
        .clip(RoundedCornerShape(16.dp)).background(Color.White).clickable { onClick() }) {
        if (img != null) {
            Image(bitmap = img, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.35f)))
        } else {
            AnimatedBrazilBackground(Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.25f)))
        }
        Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Text(category.title, color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(category.summary, color = Color.Black, fontSize = 12.sp, maxLines = 3)
        }
    }
}

@Composable
fun CategoryDetail(category: Category) {
    val detailBg = assetImageOrNull("backgrounds/plant_detail/${category.key}.jpg")
        ?: assetImageOrNull("backgrounds/plant_detail/${category.key}.png")

    Box(modifier = Modifier.fillMaxWidth().heightIn(min = 300.dp)) {
        if (detailBg != null) {
            Image(bitmap = detailBg, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(160.dp))
        } else {
            AnimatedBrazilBackground(modifier = Modifier.fillMaxWidth().height(160.dp))
        }
    }
    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
        Text(category.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        Spacer(Modifier.height(8.dp))
        Text(category.detail, fontSize = 14.sp, color = Color.Black.copy(alpha = 0.9f), lineHeight = 20.sp)
        Spacer(Modifier.height(12.dp))
        Text("Resumen: " + category.summary, fontWeight = FontWeight.SemiBold, color = Color.Black)
        Spacer(Modifier.height(12.dp))
    }
}
