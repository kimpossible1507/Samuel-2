Coloque aqui seus arquivos para personalização visual e áudio.

ESTRUTURA:
- assets/backgrounds/home/             -> Imagem de fundo da tela inicial (ex.: home.jpg / home.png)
- assets/backgrounds/menu/             -> Imagem de fundo do menu lateral (ex.: menu.jpg)
- assets/backgrounds/categories/       -> Imagens de fundo para cada QUADRO/CATEGORIA (ex.: morfologia.jpg, quimica_digestiva.jpg)
- assets/backgrounds/plant_detail/     -> Imagem de fundo da área de detalhe/3D
- assets/audio/                        -> 1..N arquivos .mp3 (serão tocados em sequência com volume baixo)

FONTES (opcional):
- Coloque um arquivo em res/font/app_font.ttf (substitua o placeholder) para aplicar ao app todo.
  Se não existir, será usada a fonte padrão do sistema.

NOMES SUGERIDOS PARA CATEGORIAS (backgrounds/categories/):
- morfologia.jpg
- fotosintesis.jpg
- quimica_digestiva.jpg
- microbiota.jpg
- absorcion.jpg
- germinacion.jpg
- ecologia.jpg
- cuidados.jpg
- reproduccion.jpg
- conservacion.jpg

Dica: você pode usar .png ou .jpg. Se a imagem não existir, o app usa um degradê animado como fallback.
